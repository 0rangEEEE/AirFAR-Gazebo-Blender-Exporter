Air-FAR Gazebo Classic map export: maze

1. Copy this entire *_gazebo_bundle folder or its zip to your Ubuntu VM.
2. Ubuntu: python3 install_map.py --workspace ~/airfar_ws/aerial_autonomy_development_environment
3. Simulator: source /opt/ros/noetic/setup.bash; source ~/airfar_ws/aerial_autonomy_development_environment/devel/setup.bash
   roslaunch vehicle_simulator start_maze.launch
4. Planner (new terminal): source /opt/ros/noetic/setup.bash; source ~/airfar_ws/aerial_autonomy_development_environment/devel/setup.bash; source ~/airfar_ws/Air-FAR/devel/setup.bash
   roslaunch airfar_planner airfar.launch config_file:=default rviz_file:=airfar_tunnel
5. Check: rosnode ping -c 1 /gazebo; rostopic hz /registered_scan; rostopic echo -n 1 /state_estimation/pose/pose/position

Spawn from Blender UAV_SPAWN object (meters, yaw in radians): [-2.865382432937622, -8.80042552947998, 3.691241502761841, 0.0]
Note: Visuals are split by material with explicit SDF ambient/diffuse colors.
Full static overview preview/pointcloud.ply is generated for RViz visualization only (not navigation prior).
Do not assume all Blender effects / Geometry Nodes / PBR materials are exported.
Notes:
- No COL_ meshes found; using ALL visual geometry for collision. For large scenes, create simplified COL_ collision meshes.
- Skipped degenerate face in 平面.001
- Skipped degenerate face in 平面.001
- Skipped degenerate face in 平面.001
- Skipped degenerate face in 平面.001
- Skipped degenerate face in 平面.001
- Skipped degenerate face in 平面.001
- Skipped degenerate face in 平面.001
- Skipped degenerate face in 平面.001
- Skipped degenerate face in 平面.001
- Skipped degenerate face in 平面.001
- Skipped degenerate face in 平面.001
- Skipped degenerate face in 平面.001
- Skipped degenerate face in 平面.001
- Skipped degenerate face in 平面.001
- Skipped degenerate face in 平面.001
- Skipped degenerate face in 平面.001
- Skipped degenerate face in 平面.001
- Skipped degenerate face in 平面.001
- Skipped degenerate face in 平面.001
- Skipped degenerate face in 平面.001
